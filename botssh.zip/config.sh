#### AREA DE CONFIGURAÇÃO BOT SSH ####
export ip_server2="IP-DA-VPS"

export senha_server2="SENHA-VPS"

export user="@USER DO TELEGRAM"

export pix_nome="NOME DO BENEFICIARIO PIX"

export pix_chave="SUA CHAVE PIX"

export login_valor="20,00"

export link_pv="LINK DO SEU PV"

export dowload_app="LINK DE DOWLOAD DO SEU APP"

export operadoras="🟣VIVO 🔵TIM 🔴CLARO"

export nome_do_bot="BOT SSH TESTE"
########################################
QUALQUER LINK ERRADO NAO LIGARA O BOT !!
########################################


