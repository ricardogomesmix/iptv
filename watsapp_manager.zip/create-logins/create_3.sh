#!/usr/bin/env bash
    usuario=$LOGIN
    senha=$SENHA
    limite='3'
    dias='31'

    final=$(date "+%Y-%m-%d" -d "+$dias days")
    gui=$(date "+%d/%m/%Y" -d "+$dias days")
    pass=$(perl -e 'print crypt($ARGV[0], "password")' $senha)
    useradd -e $final -M -s /bin/false -p $pass $usuario >/dev/null 2>&1 &
    echo "$usuario $limite" >>/root/usuarios.db
    echo "$senha" >/etc/SSHPlus/senha/$usuario