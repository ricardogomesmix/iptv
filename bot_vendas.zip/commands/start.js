const GerenciaPix = require("../GerenciaPix.js");
const fetch = require("node-fetch");
const ms = require("pixapi");
const ms1 = require("parse-ms");
const { exec } = require(`child_process`);
const { spawn } = require("child_process");
module.exports = async (bot,msg,database,PixApi,FATURA,GRUPO,LINK_APP,IP_SERVER,LINK_PV) => {
  
  const author = msg.from.username;
  const button_login = "ACESSO VPN";
  const login_valor = "20.00";

  const options = {
    parse_mode: "html",
    reply_markup: JSON.stringify({
      inline_keyboard: [
        [{ text: "Comprar acesso VPN", callback_data: "1" }],
        [{ text: "Criar teste Gratis", callback_data: "2" }],
        [{ text: "Checar Validade", callback_data: "check" }],
        [{ text: "Suporte ao Cliente", url: LINK_PV }],
        [{ text: "Sair do Menu", callback_data: "4" }],
      ],
    }),
  };

  let start_msg;
  start_msg = `<b>BEM VINDOª COMO POSSO TE AJUDAR?</b>`;
  bot.sendMessage(msg.chat.id, start_msg, options);

  let msg_button = "<b>📌 DETALHES DA COMPRA 📌</b>\n\n";
  msg_button += `<b>🛍️ PRODUTO:</b> ${button_login}\n`;
  msg_button += `<b>💰 PREÇO:</b> ${FATURA}\n`;
  msg_button += `<b>📅 VALIDADE:</b> 30 Dias\n\n`;
  msg_button += `<b>Deseja continuar a compra?</b>`;

  bot.on("callback_query", async (callbackQuery) => {
    const action = callbackQuery.data;
    const msg = callbackQuery.message;
    const opts_button = {
      reply_markup: JSON.stringify({
        inline_keyboard: [
          [{ text: "Pagar com PIX", callback_data: "sim" }],
          [{ text: "Cancelar Compra", callback_data: "nao" }],
        ],
      }),
      chat_id: msg.chat.id,
      message_id: msg.message_id,
      parse_mode: "html",
    };

    let text;
    if (action == "1") {
    bot.editMessageText(msg_button, opts_button);
    return;
    }

    if (action == "4") {
      let op = {
        chat_id: msg.chat.id,
        message_id: msg.message_id,
        parse_mode: "html",
      };
      
      bot.editMessageText("<b>✅ Atendimento automático finalizado.\nPara iniciar outro utilize /start</b>",op);
      bot.db.delete(`Start/${msg.chat.id}/start`);
      return;
    }

    if (action == "check") {
      require("./check.js")(msg, bot, action,IP_SERVER);
      return;
    }


    let db = await bot.db.get(`CheckUser`);
    db = db || {};

    if (Object.keys(db).includes(action)) {
      require("../utils/checkuser.js")(db[action].login,msg,bot,IP_SERVER);
      return;
    }

    if (action == "2") {
      let c = {
        chat_id: msg.chat.id,
        message_id: msg.message_id,
        parse_mode: "html"
      };
      let testetempo = await bot.db.get(`TesteSSH/${msg.chat.id}`);
      let timeout = 86400000;
      if (
        testetempo.tempo !== null &&
        timeout - (Date.now() - testetempo.tempo) > 0
      ) {
        bot.editMessageText("Você só pode criar 1 teste a cada 24 horas.", c);
        bot.removeListener("callback_query");
        bot.db.delete(`Start/${msg.chat.id}/start`);
        return;
      } else {
        
        const senhateste = ms.randomNumber(1000, 10000);
        const userteste = `TESTE${senhateste}`;
        
        const child = spawn("bash teste.sh", ["teste.sh"], {
          shell: true,
          env: {
            SENHA: senhateste,
            LOGIN: userteste,
          },
        });

        child.stdout.pipe(process.stdout);
        let pt = {
        parse_mode: "Markdown",
        };
        
        const applink = {
          chat_id: msg.chat.id,
          message_id: msg.message_id,
          parse_mode: "html",
          reply_markup: JSON.stringify({
            inline_keyboard: [
              [{ text: "🔰 Dowload Aplicativo 🔰", url: LINK_APP }],
            ],
          }),
        };
        
        let testemsg;
        testemsg = `<b>✅ CRIADO COM SUCESSO !</b>\n\n`;
        testemsg += `<b>USUÁRIO:</b> <code>${userteste}</code>\n`;
        testemsg += `<b>SENHA:</b> <code>${senhateste}</code>\n`;
        testemsg += "<b>LIMITE: 1</b>\n";
        testemsg += "<b>EXPIRA EM: 1hora</b>\n\n";
        testemsg +=
          "Faça o dowload do aplicativo para conexão clicando no botão abaixo:";

        bot.editMessageText(testemsg, applink);
        await bot.db.set(`TesteSSH/${msg.chat.id}`, { tempo: Date.now() });
        await bot.db.delete(`Start/${msg.chat.id}/start`);
      }
    }

    const button2 = {
      parse_mode: "html",
      reply_markup: JSON.stringify({
        inline_keyboard: [
          [{ text: "Pagar com PIX", callback_data: "sim" }],
          [{ text: "Cancelar Fatura", callback_data: "nao" }],
        ],
      }),
    };

    const opts = {
      chat_id: msg.chat.id,
      message_id: msg.message_id,
      parse_mode: "html",
    };

    const message_id = msg.message_id;

    if (action == "sim") {
      PixApi.CriarFatura(`${FATURA}`).then(async (res) => {
        let groupmsg = "<b>🛒 LINK DE PAGAMENTO GERADO 🛒</b>\n\n";
        groupmsg += `<b>👤 GERADO POR:</b> @${author}\n`;
        groupmsg += `<b>🛍️ PRODUTO:</b> ${button_login}\n\n`;
        groupmsg += `<b>📬 ID DA COMPRA:</b> ${res.id}`;

        const dbref = database.ref(`Compras/${res.id}`);
        text = `<b>✅ Copie o codigo e pague usando o copia e cola do seu banco:</b>\n\n<code>${res.codigo}</code>\n\n<b>📌 Você receberá seu acesso automáticamente após realizar o pagamento.</b>\n\n<b>📬 FATURA: #${res.id}</b>`;

        bot.editMessageText(text, opts);
        bot.sendMessage(GRUPO, groupmsg, opts);

        await dbref.set({
          chat: msg.chat.id,
          compra_id: res.id,
          pago: "Não",
          usuario: author,
          msg_id: message_id,
        });
      });
      bot.removeListener("callback_query");
    }

    if (action == "nao") {
      let nao = "<b>CANCELADO COM SUCESSO !</b>";
      bot.editMessageText(nao, opts);
      bot.removeListener("callback_query");
      bot.db.delete(`Start/${msg.chat.id}/start`);
    }
  });
};