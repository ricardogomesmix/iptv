module.exports = async (bot, msg, database) => {
  const opts = {
    parse_mode: 'html'
  }
  let db = await bot.db.get(`Start/${msg.chat.id}`)
  if (db == null) {
    bot.sendMessage(msg.chat.id, 'Você ainda não possui um menu aberto, abra um clicando em /start')
  } else {

    bot.sendMessage(msg.chat.id, '<b>ATENDIMENTO AUTOMÁTICO FINALIZADO, INICIE OUTRO CLICANDO EM /start</b>', opts)
    await bot.db.delete(`Start/${msg.chat.id}/start`)
  }
  
}